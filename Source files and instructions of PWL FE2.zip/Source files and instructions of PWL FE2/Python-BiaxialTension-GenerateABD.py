#coding=utf-8
""""
The script is used for bulk generation of ABD matrices for the substrate RVE
Author: Longlong Chen
"""

#Modify the installation path of the Micromechanics plugin and the working directory of the Abaqus job
pluginpath='D:/Software/SIMULIA2023/Plugins/MicroMechanics_v1.18/MicroMechanics'
workingpath='E:/Abaqus2023Doc/WorkingTemp'

########Import packages
from abaqus import * 
from abaqusConstants import * 
import __main__ 
import section 
import regionToolset 
import displayGroupMdbToolset as dgm 
import part 
import material 
import assembly 
import step 
import interaction 
import load 
import mesh 
import job 
import sketch 
import visualization 
import xyPlot 
import displayGroupOdbToolset as dgo 
import connectorBehavior
import sys
sys.path.insert(8, pluginpath)
import microMechanics
from microMechanics.mmpBackend import Interface
from microMechanics.mmpBackend.mmpInterface.mmpRVEConstants import *
from microMechanics.mmpBackend.mmpKernel.mmpLibrary import mmpRVEGenerationUtils as RVEGenerationUtils

########Define model parameters
modelname='Model-BiaxialTension-GenerateABD'
#Determine the approximate strain range in the 1-direction and 2-direction
maxstrain1=0.02; maxstrain2=0.01
#Determine the number of constitutive segments in the 1-direction and 2-direction
m=10; n=10
#Define material constants
E3=5000; G=1000

#Define the constitutive relation
def stress(strain):
    stress=-100000*strain**2+5000*strain
    return stress

#Calculate the 1-direction elastic modulus and section forces at division points
E1=[]
for i in range(m):
    stress11=stress(maxstrain1*i/m)
    stress12=stress(maxstrain1*(i+1)/m)
    E1.append((stress12-stress11)/(maxstrain1/m))

#Calculate the 2-direction elastic modulus and section forces at division points
E2=[]
for i in range(n):
    stress21=stress(maxstrain2*i/n)
    stress22=stress(maxstrain2*(i+1)/n)
    E2.append((stress22-stress21)/(maxstrain2/n))

#Automatically apply PBCs using the plugin and creat the basic job
basicjob='Job-RVE-GenerateABD'
a = mdb.models[modelname].rootAssembly
mdb.Job(name=basicjob, model=modelname, description='', 
    type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, 
    memory=90, memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, numThreadsPerMpiProcess=1, 
    multiprocessingMode=DEFAULT, numCpus=8, numDomains=8, numGPUs=0)
Interface.Loading.abdModelMaker(modelName=modelname, 
    jobName=basicjob, doNotSubmit=True, 
    homogenizeProperties=(True, True, True))

########Job submission and post-processing of ABD matrices
for i in range(m):
    for j in range(n):
        #Assign material parameters of the substrate
        jobname='Job-RVE-GenerateABD-%d-%d'%(i+1, j+1)
        mdb.models[modelname].materials['MATERIAL-SUBSTRATE'].elastic.setValues(
        table=((E1[i], 0, E2[j], 0, 0, E3, G, G, G), ))
        #Copy the basic job and submit for computation
        mdb.Job(name=jobname, objectToCopy=mdb.jobs[basicjob])
        mdb.jobs[jobname].submit(consistencyChecking=OFF)
        mdb.jobs[jobname].waitForCompletion()
        
        #Output the ABD matrix 
        Interface.PostProcess.ABDPostProcessWorkflow(model=modelname, 
            ODBName=workingpath+'/Job-RVE-GenerateABD-%d-%d.odb'%(i+1,j+1), 
            doHomogenization=True, materialType=('ABD matrices', ), 
            fieldAveraging=False, getStrainConcentration=False, averageVolume=False, 
            averageVolumeBySection=False, selectedFields=(), 
            getStatisticalDistribution=False)
        if ('HomgABD-%d-%d'%(i+1,j+1) in mdb.models[modelname].sections):
            del mdb.models[modelname].sections['HomgABD-%d-%d'%(i+1,j+1)]
        
        session.odbs[workingpath+'/Job-RVE-GenerateABD-%d-%d.odb'%(i+1,j+1)].close()
        #Rename the ABD matrix
        mdb.models[modelname].sections.changeKey(
            fromName='HomgABD_0pt0', toName='HomgABD-%d-%d'%(i+1,j+1))
        
        del mdb.jobs['Job-RVE-GenerateABD-%d-%d'%(i+1, j+1)]

del mdb.jobs[basicjob]