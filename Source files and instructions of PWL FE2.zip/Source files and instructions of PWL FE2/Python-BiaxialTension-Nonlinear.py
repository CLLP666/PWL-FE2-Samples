#coding=utf-8
""""
The script is used for nonlinear simulation of the substrate subjected to biaxial tension
Author: Longlong Chen
"""

#Modify the working directory of the Abaqus job
workingpath='E:/Abaqus2023Doc/WorkingTemp'

########Import packages
from abaqus import * 
from abaqusConstants import * 
import __main__ 
import section 
import regionToolset 
import displayGroupMdbToolset as dgm 
import part 
import material 
import assembly 
import step 
import interaction 
import load 
import mesh 
import job 
import sketch 
import visualization 
import xyPlot 
import displayGroupOdbToolset as dgo 
import connectorBehavior
import csv

########Define model parameters
modelname='Model-BiaxialTension-Nonlinear'
# Input the number of constitutive segments, thickness and approximate strain range
m=10; n=10; thick=0.27; maxstrain1=0.02; maxstrain2=0.01
#Determine the number of load segments
r=10

#Define the constitutive relation
def stress(strain):
    stress=-100000*strain**2+5000*strain
    return stress

#Calculate the 1-direction section forces at division points
SF1=[]
for i in range(m):
    stress12=stress(maxstrain1*(i+1)/m)
    SF12=stress12*thick
    SF1.append(SF12)

#Calculate the 2-direction section forces at division points
SF2=[]
for i in range(n):
    stress22=stress(maxstrain2*(i+1)/n)
    SF22=stress22*thick
    SF2.append(SF22)

#Define the function to 
breakpoints1= SF1
breakpoints2 = SF2
def find_interval(data, breakpoints):
    interval_index = None
    for index, breakpoint in enumerate(breakpoints):
        if data < breakpoint:
            interval_index=max(1,index+1)
            break
    if interval_index==None:
        interval_index=len(breakpoints)
    return interval_index

# Define the function to retrieve the row number of the model keyword.
def keywordnum(modelname, blockstr):
    model=mdb.models[modelname]
    model.keywordBlock.synchVersions(
        storeNodesAndElements=False)
    for n, block in enumerate(model.keywordBlock.sieBlocks):
        if block[0:len(blockstr)].lower() == blockstr.lower():
            preline=n-1
            return preline
            break
    
    else:
            print('the keyword is not found')


for i in range(0,r):
    if i>0:
        del mdb.models[modelname].parts['PART-1']
        previousodb=workingpath+'/Job'+modelname[5:]+str(i)+'.odb'
        session.openOdb(previousodb)
        odb = session.odbs[previousodb]
        numstep=len(odb.steps.keys()); 
        stepname=odb.steps.keys()[numstep-1]
        numframe=len(odb.steps[stepname].frames)
        #Import the deformed part
        p = mdb.models[modelname].PartFromOdb(name='PART-1', instance='PART-1-1', 
            odb=odb, shape=DEFORMED, step=numstep-1, frame=numframe-1)
        session.viewports['Viewport: 1'].setValues(displayedObject=p)
        mdb.models[modelname].keywordBlock.setValues(edited = 0)
        mdb.models[modelname].keywordBlock.synchVersions(
            storeNodesAndElements=False)
        blockstr='*Step, name='
        preline=keywordnum(modelname, blockstr)
        previousjob='Job'+modelname[5:]+str(i)
        previouscsv=previousjob+'-SF-New.csv'
        #Import the initial stress
        initialstress='*initial conditions, type=stress, input={}' .format (previouscsv)
        mdb.models[modelname].keywordBlock.insert(preline, initialstress)
    
    #Delete the section assignments and element sets
    p = mdb.models[modelname].parts['PART-1']
    e=p.elements
    indexe=[]
    for j in range(len(e)):
        indexe.append(e[j].label)
    Setnames = p.sets.keys()
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    for j in range(len(p.sectionAssignments)):
        del p.sectionAssignments[0]
    
    for j in range(m):
        for k in range(n):
            Setname='SET-ABD-%d-%d'%(j+1, k+1)
            if  Setname in Setnames:
                del p.sets[Setname]
    
    #Creat element sets of ABD shells
    if i==0:
        p.Set(name='SET-ABD-1-1', objectToCopy=p.sets['SET-ABD'])
        for j in range(m):
            for k in range(n):
                    if not(j==0 and k==0):
                        p.Set(elements=e[1:1], name='SET-ABD-%d-%d'%(j+1, k+1))
    
    elif i>0:
        Elementset= [[e[0:0] for _ in range(n)] for _ in range(m)]
        with open(previouscsv, 'r') as csvfile:
            #Creat a CSV file reader
            reader = csv.reader(csvfile)
            row_count = len(list(reader))
            csvfile.seek(0)
            col_count = len(next(reader))
            breakpoints1=SF1
            breakpoints2=SF2
            for j in range(row_count):
                #Read element labels and section forces
                row1=linecache.getline(previouscsv,1+j)
                str1=row1.split(',', col_count)[0]
                label=int(str1.split('.', 2)[1])
                sectionforce1=float(row1.split(',', col_count)[1])
                sectionforce2=float(row1.split(',', col_count)[2])
                indexset1=find_interval(sectionforce1, breakpoints1)
                indexset2=find_interval(sectionforce2, breakpoints2)
                num=indexe.index(label)
                #Creat element sets based on section forces
                Elementset[indexset1-1][indexset2-1]=Elementset[indexset1-1][indexset2-1]+e[num:num+1]
        
        #Creat element sets of ABD shells
        for j in range(m):
            for k in range(n):
                p.Set(elements=Elementset[j][k], name='SET-ABD-%d-%d'%(j+1, k+1))
    
    #Assign material properties
    for j in range(m):
        for k in range(n):
            region = p.sets['SET-ABD-%d-%d'%(j+1, k+1)]
            p.SectionAssignment(region=region, sectionName='HomgABD-%d-%d'%(j+1, k+1), offset=0.0, 
                offsetType=MIDDLE_SURFACE, offsetField='', 
                thicknessAssignment=FROM_SECTION)
    
    a = mdb.models[modelname].rootAssembly
    a.regenerate()
    #Apply boundary conditions and loads
    if i==0:
        #Apply boundary conditions
        region=a.instances['PART-1-1'].sets['SET-CENTER']
        for j in range(2,5):
            a.engineeringFeatures.SpringDashpotToGround(name='Springs/Dashpots-DOF%d'%(j+1), 
                region=region, orientation=None, dof=j+1, springBehavior=ON, 
                springStiffness=1.0, dashpotBehavior=OFF, dashpotCoefficient=0.0)
        
        #Apply loads
        mdb.models[modelname].ExpressionField(name='AnalyticalField-1', 
            localCsys=None, description='', expression='0.01*Y')
        region = a.instances['PART-1-1'].sets['SET-LEFT']
        mdb.models[modelname].DisplacementBC(name='BC-1', 
            createStepName='Step-1', region=region, u1=-0.1, u2=UNSET, u3=UNSET, 
            ur1=UNSET, ur2=UNSET, ur3=UNSET, amplitude=UNSET, fixed=OFF, 
            distributionType=FIELD, fieldName='AnalyticalField-1', localCsys=None)
        region = a.instances['PART-1-1'].sets['SET-RIGHT']
        mdb.models[modelname].DisplacementBC(name='BC-2', 
            createStepName='Step-1', region=region, u1=0.1, u2=UNSET, u3=UNSET, 
            ur1=UNSET, ur2=UNSET, ur3=UNSET, amplitude=UNSET, fixed=OFF, 
            distributionType=FIELD, fieldName='AnalyticalField-1', localCsys=None)
        mdb.models[modelname].ExpressionField(name='AnalyticalField-2', 
            localCsys=None, description='', expression='0.005*X')
        region = a.instances['PART-1-1'].sets['SET-TOP']
        mdb.models[modelname].DisplacementBC(name='BC-3', 
            createStepName='Step-1', region=region, u1=UNSET, u2=0.1, u3=UNSET, 
            ur1=UNSET, ur2=UNSET, ur3=UNSET, amplitude=UNSET, fixed=OFF, 
            distributionType=FIELD, fieldName='AnalyticalField-2', localCsys=None)
        region = a.instances['PART-1-1'].sets['SET-BOTTOM']
        mdb.models[modelname].DisplacementBC(name='BC-4', 
            createStepName='Step-1', region=region, u1=UNSET, u2=-0.1, u3=UNSET, 
            ur1=UNSET, ur2=UNSET, ur3=UNSET, amplitude=UNSET, fixed=OFF, 
            distributionType=FIELD, fieldName='AnalyticalField-2', localCsys=None)
    
    #Creat a new job
    jobname='Job'+modelname[5:]+str(i+1)
    mdb.Job(name=jobname, model=modelname, description='', 
        type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, 
        memory=90, memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
        scratch='', resultsFormat=ODB, numThreadsPerMpiProcess=1, 
        multiprocessingMode=DEFAULT, numCpus=8, numDomains=8, numGPUs=0)
    #Submit the job
    mdb.jobs[jobname].submit(consistencyChecking=OFF)
    mdb.jobs[jobname].waitForCompletion() 
    #Fieldout of section forces
    odbname=workingpath+'/'+jobname+'.odb'
    o3= session.openOdb(name=odbname)
    session.viewports['Viewport: 1'].setValues(displayedObject=o3)
    session.viewports['Viewport: 1'].makeCurrent()
    odb=session.odbs[odbname]
    nstep=len(odb.steps)
    nframe=len(odb.steps['Step-1'].frames)
    outputcsv=jobname+'-SF.csv'
    session.fieldReportOptions.setValues(reportFormat=COMMA_SEPARATED_VALUES)
    session.writeFieldReport(fileName=outputcsv, append=OFF, 
        sortItem='Element Label', odb=odb, step=nstep-1, frame=nframe-1, 
        outputPosition=INTEGRATION_POINT, variable=(('SF', INTEGRATION_POINT, ((
        COMPONENT, 'SF1'), (COMPONENT, 'SF2'), (COMPONENT, 'SF3'), )), ('SM', 
        INTEGRATION_POINT, ((COMPONENT, 'SM1'), (COMPONENT, 'SM2'), (COMPONENT, 'SM3'), )), ), 
        stepFrame=SPECIFY)
    session.odbs[odbname].close()
    
    #Processing the data of  section forces
    SFData=[]
    with open(outputcsv, 'r') as csvfile:
        #Creat a CSV file reader
        reader = csv.reader(csvfile)
        row_count = len(list(reader))
        csvfile.seek(0)
        col_count = len(next(reader))
        for j in range(row_count-1):
            #Read element labels and section forces
            row1=linecache.getline(outputcsv,2+j)
            str11=row1.split(',', col_count)[3][1:-1]    #Remove the double quotes from str11
            str12=row1.split(',', col_count)[4].strip()   #Remove the spaces before and after the numbers
            str13=float(row1.split(',', col_count)[12])  
            str14=float(row1.split(',', col_count)[13]) 
            str15=float(row1.split(',', col_count)[14]) 
            str16=float(row1.split(',', col_count)[15]) 
            str17=float(row1.split(',', col_count)[16]) 
            str18=float(row1.split(',', col_count)[17]) 
            SFData1=str11+'.'+str12
            SFData2=str13  #SF1
            SFData3=str14  #SF2
            SFData4=str15  #SF3
            SFData5=str16  #SM1
            SFData6=str17  #SM2
            SFData7=str18  #SM3
            SFData.append([SFData1,SFData2,SFData3,SFData4,SFData5,SFData6,SFData7])
    
    # Write the processed data into a new file
    newcsv=jobname+'-SF-New.csv'
    with open(newcsv, 'wb') as newfile:
        writer = csv.writer(newfile)
        writer.writerows(SFData)
